class Converter:
    def __init__(self,kg,pounds):
        self.kg = kg
        self.pounds = pounds
        

    def Convert(self):
        if self.kg == 'kg' and self.pounds == 'pounds':
            print(self.kg/2.20462, 'Pounds')
        if self.pounds == 'pounds' and self.kg == 'kg':
            print(self.pounds*0.45, 'kg')

kg = Converter(70,'Kilograms')
Lbs = Converter(1,'Pounds')
kg.Convert()
Lbs.Convert()

