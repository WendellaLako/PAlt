from tkinter import *

window = Tk()
window.title("GUI Example")
window.geometry("250x250")
window.config(padx=80, pady=100)
input = True

def Change():
    global input
    if input:
        labelText["text"] = "I have been changed"
        input = False

    else:
        labelText["text"] = "Changed Text"
        input = True

labelText = Label(text="Changed Text")
btnChangeText = Button(text="Change Text",command=Change)

labelText.grid(row=4,column=1)
btnChangeText.grid(row=2,column=1)

window.mainloop()
