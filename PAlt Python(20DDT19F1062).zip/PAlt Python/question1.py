password = 11111
max_attempt = 5

i = 0

while i < max_attempt:
    guess = int(input('Enter password: '))
    i +=1
    if guess == password:
        print('You have logged into the system!')

    else:
        print('You have been blocked from the system')
